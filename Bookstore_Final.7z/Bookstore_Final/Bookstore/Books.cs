﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Bookstore
{
    class Books
    {
        private string book;
        private string publisher;
        private string author;
        private byte bookType;
        private double price;
        private ushort number;

        public Books()
        { }

        public Books(string book, string publisher, string author, byte bookType, double price, ushort number)
        {
            this.book = book;
            this.publisher = publisher;
            this.author = author;
            this.bookType = bookType;
            this.price = price;
            this.number = number;
        }

        public string Book
        {
            get { return this.book; }
            set { this.book = value; }
        }

        public string Publisher
        {
            get { return this.publisher; }
            set { this.publisher = value; }
        }

        public string Author
        {
            get { return this.author; }
            set { this.author = value; }
        }

        public byte BookType
        {
            get { return this.bookType; }
            set { this.bookType = value; }
        }

        public double Price
        {
            get { return this.price; }
            set { this.price = value; }
        }

        public ushort Number
        {
            get { return this.number; }
            set { this.number = value; }
        }
    }
}
