﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Bookstore
{
    public partial class Form1 : Form
    {
        Books[] bookArr = new Books[100];
        string[] type = new string[13];
        int i, k; string t;

        void InitType()
        {
            type[0] = "Хуманитарна литература";
            type[1] = "Художествена литература";
            type[2] = "Психология";
            type[3] = "Компютри";
            type[4] = "Чужди езици";
            type[5] = "Техника";
            type[6] = "Медицина";
            type[7] = "Икономика";
            type[8] = "Справочна литература";
            type[9] = "Право";
            type[10] = "Хоби";
            type[11] = "Детска литература";
            type[12] = "Друг";
        }

        void LoadType()
        {
            for (int j = 0; j < 13; j++)
            { comboBoxType.Items.Add(type[j]); }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitType();
            LoadType();
            lblTotal.Text = "0,00";

            lblNumbers.Text = "0";
            lblPrice.Text = "0,00";
        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            comboBoxBooks1.Items.Clear();
            comboBoxBooks2.Items.Clear();

            System.IO.StreamReader reader = new System.IO.StreamReader("books.txt");
            using (reader) 
            {
                i = 0; k = 0; bookArr[i] = new Books();
                t = reader.ReadLine();
                while (t != null)
                {
                    switch (k)
                    {
                        case 0: bookArr[i].Book = t; break;
                        case 1: bookArr[i].Publisher = t; break;
                        case 2: bookArr[i].Author = t; break;
                        case 3: byte typeNum = 255;
                            for (byte j = 0; typeNum == 255; j++)
                            { if (t == type[j]) typeNum = j; }
                            bookArr[i].BookType = typeNum;
                            break;
                            /*
                            byte typeNum = 255;
                            for (byte j = 0; j < 13 && typeNum == 255; j++)
                            { if (t == type[j]) typeNum = j; }
                            if (typeNum == 255) typeNum = 12;
                            bookArr[i].BookType = typeNum;
                            break;
                            */
                        case 4: bookArr[i].Price = double.Parse(t); break;
                        case 5: bookArr[i].Number = ushort.Parse(t); break;
                    }
                    t = reader.ReadLine();
                    if (k == 5) { k = 0; i++; bookArr[i] = new Books(); }
                    else k++;
                }
            }
            for (int j = 0; j < i; j++)
            { 
                comboBoxBooks1.Items.Add(bookArr[j].Book);
                comboBoxBooks2.Items.Add(bookArr[j].Book);
            }
            lblNumbers.Text = i.ToString();

            buttonNewBook.Enabled = true;
            buttonSave.Enabled = true;
        }

        private void buttonInformation_Click(object sender, EventArgs e)
        {
            int selectedBook = comboBoxBooks1.SelectedIndex;
            textBoxTitle.Text = bookArr[selectedBook].Book;
            textBoxAuthor.Text = bookArr[selectedBook].Author;
            comboBoxType.SelectedIndex = bookArr[selectedBook].BookType;
            comboBoxType.Text = comboBoxType.SelectedItem.ToString();
            textBoxPublisher.Text = bookArr[selectedBook].Publisher;
            textBoxPrice.Text = String.Format("{0:0.00}", bookArr[selectedBook].Price);
            textBoxNumber.Text = bookArr[selectedBook].Number.ToString();

            buttonAdd.Enabled = false;
        }

        private void buttonNewBook_Click(object sender, EventArgs e)
        {
            comboBoxBooks1.ResetText();
            textBoxTitle.Clear();
            textBoxAuthor.Clear();
            comboBoxType.ResetText();
            //comboBoxType.Items.Clear();
            textBoxPublisher.Clear();
            textBoxPrice.Clear();
            textBoxNumber.Clear();

            buttonInformation.Enabled = false;
            buttonAdd.Enabled = true;
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                byte typeNum = 255; t = comboBoxType.Text;
                for (byte j = 0; j < 13 && typeNum == 255; j++)
                { if (t == type[j]) typeNum = j; }
                if (typeNum == 255) typeNum = 12;
                bookArr[i] = new Books(textBoxTitle.Text, textBoxPublisher.Text, textBoxAuthor.Text, typeNum, double.Parse(textBoxPrice.Text), ushort.Parse(textBoxNumber.Text));
                i++;
                buttonAdd.Enabled = false;
            }
            catch (Exception)
            { MessageBox.Show("Неправилно въведени данни!"); }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            System.IO.StreamWriter writer = new System.IO.StreamWriter("books.txt");
            using (writer)
            {
                for (byte j = 0; j < i; j++)
                {
                    writer.WriteLine(bookArr[j].Book);
                    writer.WriteLine(bookArr[j].Publisher);
                    writer.WriteLine(bookArr[j].Author);
                    writer.WriteLine(type[bookArr[j].BookType]);
                    writer.WriteLine(bookArr[j].Price);
                    writer.WriteLine(bookArr[j].Number);
                }
            }
        }

        private void comboBoxBooks2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedBook = comboBoxBooks2.SelectedIndex;
            lblPrice.Text = String.Format("{0:0.00}", bookArr[selectedBook].Price);

            buttonAddToCart.Enabled = true;
        }

        private void buttonAddToCart_Click(object sender, EventArgs e)
        {
            int selectedBook = comboBoxBooks2.SelectedIndex;
            if (textBoxNumberBuy.Text != "")
            {
                if (ushort.Parse(textBoxNumberBuy.Text) != 0)
                {
                    if (ushort.Parse(textBoxNumberBuy.Text) <= bookArr[selectedBook].Number)
                    {
                        lbChoose.Items.Add(bookArr[selectedBook].Book + " - " + textBoxNumberBuy.Text.ToString() + " x " + String.Format("{0:0.00}", bookArr[selectedBook].Price));
                        lblTotal.Text = String.Format("{0:0.00}", double.Parse(lblTotal.Text) + double.Parse(textBoxNumberBuy.Text) * bookArr[selectedBook].Price);
                        bookArr[selectedBook].Number -= ushort.Parse(textBoxNumberBuy.Text);
                        textBoxNumberBuy.Text = "";
                    }
                    else
                        MessageBox.Show("Желаният брой книги от това заглавие не са в наличност!");
                }
                else
                    MessageBox.Show("Въведете колко броя от тази книга ще бъде закупена!");
            }
            else
                MessageBox.Show("Въведете колко броя от тази книга ще бъде закупена!");
        }

        private void comboBoxBooks1_SelectedIndexChanged(object sender, EventArgs e)
        {
            buttonInformation.Enabled = true;
        }

        private void buttonClear_Click(object sender, EventArgs e)
        {
            comboBoxBooks2.ResetText();
            lblPrice.Text = "0,00";
            textBoxNumberBuy.Clear();
            lbChoose.Items.Clear();
            lblTotal.Text = "0,00";
            buttonAddToCart.Enabled = false;
        }

        private void lblTotal_Click(object sender, EventArgs e)
        {

        }


    }
}
